@echo off
REM ============================================================================
REM  BTX Pool Miner (Windows) - btx-pool.com
REM  PPLNS, paid by validated shares. Auto-restarts on disconnect.
REM ============================================================================
title BTX Pool Miner
cd /d "%~dp0"
setlocal enabledelayedexpansion

REM ====== SET YOUR BTX ADDRESS HERE (or paste it into address.txt) ======
set "ADDRESS="
set "RIG=rig1"
REM =====================================================================

if "!ADDRESS!"=="" if exist address.txt set /p ADDRESS=<address.txt
if "!ADDRESS!"=="" (
  set /p ADDRESS="Paste your BTX address (btx1...): "
  echo !ADDRESS!>address.txt
)
if "!ADDRESS!"=="" ( echo ERROR: no address. Edit mina.bat or address.txt. & pause & exit /b 1 )

echo ============================================================
echo   BTX Pool Miner
echo   Pool   : btx-pool.com  (PPLNS, validated shares)
echo   Payout : !ADDRESS!
echo   Stop   : close this window
echo ============================================================

:loop
btx_miner.exe --stratum btx-pool.com:3334 --worker !ADDRESS!.!RIG!
echo [restart] miner stopped - retrying in 5s...
timeout /t 5 >nul
goto loop
