#!/usr/bin/env bash
# ============================================================================
#  BTX Pool Miner (Linux) — btx-pool.com
#  PPLNS, paid by validated shares. Auto-restarts on disconnect.
# ============================================================================
cd "$(dirname "$0")"
chmod +x btx_miner 2>/dev/null

# ====== SET YOUR BTX ADDRESS HERE (or paste it into address.txt) ======
ADDRESS=""
RIG="rig1"
# ======================================================================

# Fallbacks: 1) ADDRESS above  2) address.txt  3) ask once and save it
[ -z "$ADDRESS" ] && ADDRESS="$(cat address.txt 2>/dev/null | tr -d ' \r\n')"
if [ -z "$ADDRESS" ]; then
  read -r -p "Paste your BTX address (btx1...): " ADDRESS
  echo "$ADDRESS" | tr -d ' \r\n' > address.txt
fi
[ -z "$ADDRESS" ] && { echo "ERROR: no address. Edit mina.sh or address.txt."; exit 1; }
RIG="${1:-$RIG}"

echo "============================================================"
echo "  BTX Pool Miner"
echo "  Pool   : btx-pool.com  (PPLNS, validated shares)"
echo "  Payout : $ADDRESS"
echo "  Stop   : Ctrl+C"
echo "============================================================"

# Auto-restart loop: if the miner exits/disconnects, it comes back.
while true; do
  ./btx_miner --stratum btx-pool.com:3334 --worker "$ADDRESS.$RIG"
  echo "[restart] miner stopped — retrying in 5s (Ctrl+C to quit)..."
  sleep 5
done
