==============================================================
  BTX Pool Miner — btx-pool.com
==============================================================

WHAT
  GPU miner for the BTX network (post-quantum MatMul PoW).
  Mines to the btx-pool.com public pool: PPLNS, paid by
  VALIDATED shares (not self-reported hashrate), automatically,
  to YOUR address. Auto-restarts if the connection drops.

REQUIREMENTS
  - NVIDIA GPU + driver (Ampere or newer, sm_86+).
  - Linux x86-64 or Windows x64. No CUDA toolkit needed
    (the binary is self-contained).

SET YOUR ADDRESS (pick ONE)
  a) open mina.sh / mina.bat and set ADDRESS="btx1..."   (most convenient)
  b) paste your btx1... address into the file  address.txt
  c) or just run it and paste the address when asked (saved to address.txt)

RUN — LINUX
  tar xzf btx-miner-linux.tar.gz && cd btx-miner-linux
  chmod +x mina.sh btx_miner
  bash mina.sh

RUN — WINDOWS
  unzip btx-miner-windows.zip
  double-click mina.bat

NO ADDRESS YET?
  Download the separate "BTX Address Generator" from https://btx-pool.com
  It runs offline and prints a new btx1... address + master seed.
  SAVE the master seed: it controls your coins and is never on the rig.

YOUR STATS
  https://btx-pool.com   (hashrate, share %, blocks, payouts)
  Hashrate is measured from validated shares — it cannot be faked.
  Automatic payouts on mature coins (~100 confirmations).

OPTIONS (optional)
  Pick GPUs:   add  --gpu 0,1,2,3   to the btx_miner line in mina.sh/.bat
  Rig name:    bash mina.sh myrig   (Linux)
  Full list:   ./btx_miner --help

FILES
  btx_miner / btx_miner.exe   the GPU miner (self-contained)
  mina.sh / mina.bat          launch (set ADDRESS, auto-restart)
  address.txt                 optional: put your btx1... address here
  README.txt                  this file
==============================================================
